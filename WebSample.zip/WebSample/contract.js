/*function Initial() {
  var search = window.location.search;

  var BeginIndex = search.indexOf("?imgPath=");
  if(BeginIndex!=-1) {
    var filePath = search.substring(BeginIndex+9);
    document.getElementById("SignImg").src = filePath;
  }
}*/
