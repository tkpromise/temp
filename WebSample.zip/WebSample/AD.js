﻿/* global jQuery */
/*eslint-disable*/

'use strict';

// API Url

var apiUrl = 'http://localhost:8089/PPSignSDK/';
//var apiUrl = 'https://localhost:8090/PPSignSDK/';
// initialize device web api

var initUrl = apiUrl + 'InitialDevice?id=9&width=380&height=213';
// uninitialize device web api
var uninitUrl = apiUrl + 'UninitialDevice?id=9';
// get ink web api
var getInkUrl = apiUrl + 'GetInks';
// clear ink api
var clrInkUrl = apiUrl + 'Clear';
// open & close LCD api
var oplcdUrl = apiUrl + 'OpenLCD';
var cllcdUrl = apiUrl + 'CloseLCD';
// get pen width api
var penwidthUrl = apiUrl + 'SetPenWidth?Width=';
// get pen style api
var penstyUrl = apiUrl + 'SetPenStyle?Style=';
// get save drawing api
var savedrawUrl = apiUrl + 'SaveDrawingImage?';
// get size api
var getsizeUrl = apiUrl + 'GetSize';
// get point api
var getpointUrl = apiUrl + 'GetPointer';
// get about api
var aboutUrl = apiUrl + 'About';
// get Version ID api ( for L398 & E560 )
var veridUrl = apiUrl + 'VersionID';
// get pen ID api ( for L398 & E560 )
var penidUrl = apiUrl + 'PenID';
// get pad ID api ( for L398 & E560 )
var padidUrl = apiUrl + 'PadID';
// Display device information in LCD api ( only for L398 )
var diilUrl = apiUrl + 'DisplayDeviceInfoInLCD?show=';
// Get device information api
var devinfoUrl = apiUrl + 'GetDeviceInfo?type=';
// get Encode api
var encodeUrl = apiUrl + 'Encode?type=';
// get Decode api
var decodeUrl = apiUrl + 'Decode?type=';
// get Set clip api
var setclipUrl = apiUrl + 'SetClip';
// get valid api
var validUrl = apiUrl + 'IsValid';
// save device data api
var savedataUrl = apiUrl + 'SaveDeviceData';
// read device data api
var readdataUrl = apiUrl + 'ReadDeviceData';
// save device data api
var cleardataUrl = apiUrl + 'ClearDeviceData';
// Get Decode File Path
var decodepathUrl = apiUrl + 'GetDecodeFilePath';
// GetDeviceConfirmOrCancelKeyStatus
var confirmStatusUrl = apiUrl + 'GetDeviceConfirmOrCancelKeyStatus';
// Save draw video
var saveDrawingVideoUrl = apiUrl + 'SaveDrawingVideo';
// Get video base64 code
var getDrawingVideoBase64DataUrl = apiUrl + 'GetDrawingVideoBase64Data';
// Enable Save Video Data
var enableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=1';
var disableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=0';

var UpdateSignCanvasPositionUrl = apiUrl + 'UpdateWebSignatureCanvasPosition?';

var PWC_SignatureCompleted = apiUrl + 'PWC_SignatureCompleted';

var PrerealTop = -2;
var Prerealleft = -2;
var Prerealwidth = -2;
var Prerealheight = -2;

function UpdateCanvasPosition() {
  var realTop = -1;
  var realleft = -1;
  var realwidth = -1;
  var realheight = -1;

  var RequestParameter = 'nLeft='+realleft.toFixed(0)+'&nTop='+realTop.toFixed(0)+'&nWidth='+realwidth.toFixed(0)+'&nHeight='+realheight.toFixed(0);

  $.ajax({
      url: UpdateSignCanvasPositionUrl+RequestParameter,
      type: 'GET',
      cache: false,
  }).done(function(data) {
  }).always(function() {
  });
};

function Initial() {
  UpdateCanvasPosition();
}
