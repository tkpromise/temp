﻿/* global jQuery */
/*eslint-disable*/

'use strict';

// API Url

var apiUrl = 'http://localhost:8089/PPSignSDK/';
//var apiUrl = 'https://localhost:8090/PPSignSDK/';
// initialize device web api

var initUrl = apiUrl + 'InitialDevice?id=9&width=380&height=213';
// uninitialize device web api
var uninitUrl = apiUrl + 'UninitialDevice?id=9';
// get ink web api
var getInkUrl = apiUrl + 'GetInks';
// clear ink api
var clrInkUrl = apiUrl + 'Clear';
// open & close LCD api
var oplcdUrl = apiUrl + 'OpenLCD';
var cllcdUrl = apiUrl + 'CloseLCD';
// get pen width api
var penwidthUrl = apiUrl + 'SetPenWidth?Width=';
// get pen style api
var penstyUrl = apiUrl + 'SetPenStyle?Style=';
// get save drawing api
var savedrawUrl = apiUrl + 'SaveDrawingImage?';
// get size api
var getsizeUrl = apiUrl + 'GetSize';
// get point api
var getpointUrl = apiUrl + 'GetPointer';
// get about api
var aboutUrl = apiUrl + 'About';
// get Version ID api ( for L398 & E560 )
var veridUrl = apiUrl + 'VersionID';
// get pen ID api ( for L398 & E560 )
var penidUrl = apiUrl + 'PenID';
// get pad ID api ( for L398 & E560 )
var padidUrl = apiUrl + 'PadID';
// Display device information in LCD api ( only for L398 )
var diilUrl = apiUrl + 'DisplayDeviceInfoInLCD?show=';
// Get device information api
var devinfoUrl = apiUrl + 'GetDeviceInfo?type=';
// get Encode api
var encodeUrl = apiUrl + 'Encode?type=';
// get Decode api
var decodeUrl = apiUrl + 'Decode?type=';
// get Set clip api
var setclipUrl = apiUrl + 'SetClip';
// get valid api
var validUrl = apiUrl + 'IsValid';
// save device data api
var savedataUrl = apiUrl + 'SaveDeviceData';
// read device data api
var readdataUrl = apiUrl + 'ReadDeviceData';
// save device data api
var cleardataUrl = apiUrl + 'ClearDeviceData';
// Get Decode File Path
var decodepathUrl = apiUrl + 'GetDecodeFilePath';
// GetDeviceConfirmOrCancelKeyStatus
var confirmStatusUrl = apiUrl + 'GetDeviceConfirmOrCancelKeyStatus';
// Save draw video
var saveDrawingVideoUrl = apiUrl + 'SaveDrawingVideo';
// Get video base64 code
var getDrawingVideoBase64DataUrl = apiUrl + 'GetDrawingVideoBase64Data';
// Enable Save Video Data
var enableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=1';
var disableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=0';

var UpdateSignCanvasPositionUrl = apiUrl + 'UpdateWebSignatureCanvasPosition?';
var EnableMouseUrl = apiUrl + 'EnableMouse?enable=1';
var DisableMouseUrl = apiUrl + 'EnableMouse?enable=0';

var PWC_SignatureCompleted = apiUrl + 'PWC_SignatureCompleted';

var canvas;
var context;

var isPolling = false;

var filenameCache = '';
var checkVideoIsGeneratge = false;
var isFirstPlay = true;

var LastVideoBase64Resp;

var DpiRatio = 1.0;
var SignWidth = 380;
var SignHeight = 190;


function ShowContrast() {
  document.getElementById("SignBody").className = "SignBody show-class";
  //document.getElementById("ADBody").className = "ADBody hide-class";

  window.scrollTo(0, 0);

  var scrolledCt = document.getElementById("scrolledCt");
  scrolledCt.scrollTop = 0;
};

function ScrollUp() {
  /*var obj = document.getElementById("scrolledCt");
  obj.scrollTop = obj.scrollTop - 120;*/
  document.documentElement.scrollTop = document.documentElement.scrollTop - 120;
};

function ScrollDown() {
  /*var obj = document.getElementById("scrolledCt");
  obj.scrollTop = obj.scrollTop + 120;*/
  document.documentElement.scrollTop = document.documentElement.scrollTop + 120;
};

window.onload = function(e) {
};

// initialize device
function initDevice() {
  isPolling = true;
  getInk();
  UpdateCanvasPosition();
};





// uninitialize device
function uninitDevice() {
    //event.preventDefault();
    isPolling = false;

    $.ajax({
        url: uninitUrl,
        type: 'GET',
        cache: false,
    }).done(function(response) {
        if(response === true) {
        };
    });
};

function getInk() {
    // 用polling的方式向self-host發送request取得簽名板畫面(base64格式)
    (function poll() {
        var timeId = setTimeout(function() {

            clearTimeout(timeId);

            if(isPolling)
            {
              $.ajax({
                  url: getInkUrl,
                  type: 'GET',
                  cache: false,
              }).done(function(data) {
                  //console.log('poll-getInkUrl');
                  var dataInfos = JSON.parse(data);

                  dataInfos.forEach(function(value) {
                      if(value.EventType === 0) {
                          drawImage(value.Image);
                      }
                  });

              }).always(function() {
                  if(isPolling) {
                      poll();
                  } else {}
              });
            }
        }, 50);
    }());
};

function drawImage(base64) {
    var dataUrl = 'data:image/png;base64,';

    dataUrl = dataUrl + base64;

    canvas = document.getElementById('ppCanvas');
    // 在image中載入圖檔，再畫到canvas呈現
    var img = new Image();

    img.addEventListener('load', function() {
        context.drawImage(this, 0, 0, canvas.width, canvas.height);
    }, false);

    img.src = dataUrl;

    //console.log(img);
};


function getPixelValue(styleString) {
  if(styleString) {
    var pxIndex = 0;
    pxIndex = styleString.indexOf('px');
    if(pxIndex!=-1) {
      return parseInt(styleString.substr(0,pxIndex));
    }
  }

  return 0;
};

function getPosition (element) {
  /*var x = 0;
  var y = 0;
  // 搭配上面的示意圖可比較輕鬆理解為何要這麼計算
  while ( element ) {
    x += element.offsetLeft - element.scrollLeft + element.clientLeft;
    y += element.offsetTop - element.scrollTop + element.clientTop;
    // 這邊有個重點，當父元素被下了 position 屬性之後他就會變成 offsetParent，所以這邊我們用迴圈不斷往上累加。
    element = element.offsetParent;
  }*/

  var rect = element.getBoundingClientRect();
  var x = rect.left;
  var y = rect.top;

  var style = element.currentStyle || window.getComputedStyle(element);

  var LeftOffset = 0;
  var TopOffset = 0;

  TopOffset += getPixelValue(style.paddingTop);
  LeftOffset += getPixelValue(style.paddingLeft);
  /*TopOffset += getPixelValue(style.marginTop);
  LeftOffset += getPixelValue(style.marginLeft);*/
  TopOffset += getPixelValue(style.getPropertyValue('border-top-width'));
  LeftOffset += getPixelValue(style.getPropertyValue('border-left-width'));

  return { x: x+LeftOffset, y: y+TopOffset };
};


function IsElementVisibleInViewPort(element) {
  var pos = getPosition(element);
  //var bcr = element.getBoundingClientRect();
  var realTop = (pos.y)*window.devicePixelRatio;
  var realleft = (pos.x)*window.devicePixelRatio;
  var realwidth = element.width*window.devicePixelRatio;
  var realheight = element.height*window.devicePixelRatio;

  /*var parentElement = document.getElementById('scrolledCt');

  var parentElementpos = getPosition(parentElement);
  var parentElementrealTop = (parentElementpos.y-document.documentElement.scrollTop)*window.devicePixelRatio;
  var parentElementrealleft = (parentElementpos.x-document.documentElement.scrollLeft)*window.devicePixelRatio;
  var parentElementrealwidth = parentElement.offsetWidth*window.devicePixelRatio;
  var parentElementrealheight = parentElement.offsetHeight*window.devicePixelRatio;

  var relativeLeft = realleft-parentElementrealleft;
  var relativeTop = realTop-parentElementrealTop;*/
  var parentElementrealwidth = window.innerWidth*window.devicePixelRatio;
  var parentElementrealheight = window.innerHeight*window.devicePixelRatio;

  var relativeLeft = realleft;
  var relativeTop = realTop;

  var relativeRight = relativeLeft+realwidth;
  var relativeBottom = relativeTop+realheight;

  if(relativeLeft<0 || relativeTop<0) {
    return false;
  }

  if(relativeRight>parentElementrealwidth || relativeBottom>parentElementrealheight) {
    return false;
  }


  return true;
};

var PrerealTop = -2;
var Prerealleft = -2;
var Prerealwidth = -2;
var Prerealheight = -2;

function UpdateCanvasPosition() {

    (function poll() {
        var timeId = setTimeout(function() {

            clearTimeout(timeId);

            var element = document.getElementById('ppCanvas');
            var pos = getPosition(element);
            //var bcr = element.getBoundingClientRect();
            var realTop = (pos.y)*window.devicePixelRatio;
            var realleft = (pos.x)*window.devicePixelRatio;
            var realwidth = element.width*window.devicePixelRatio;
            var realheight = element.height*window.devicePixelRatio;

            var IsVisibleInViewPort = IsElementVisibleInViewPort(element);
            if(IsVisibleInViewPort===false)
            {
              realTop = -1;
              realleft = -1;
              realwidth = -1;
              realheight = -1;
            }

            console.log('Canvas information : Top:'+realTop.toFixed(0)+', left:'+realleft.toFixed(0) + ','+'Width:'+realwidth.toFixed(0)+', Height:'+realheight.toFixed(0));

            var RequestParameter = 'nLeft='+realleft.toFixed(0)+'&nTop='+realTop.toFixed(0)+'&nWidth='+realwidth.toFixed(0)+'&nHeight='+realheight.toFixed(0);

            if(isPolling)
            {
              if(realTop!=PrerealTop || realleft!=Prerealleft || realwidth!=Prerealwidth || realheight!=Prerealheight)
              {
                $.ajax({
                    url: UpdateSignCanvasPositionUrl+RequestParameter,
                    type: 'GET',
                    cache: false,
                }).done(function(data) {
                }).always(function() {
                    if(isPolling) {
                        poll();
                    } else {}
                });
              }
              else {
                if(isPolling) {
                    poll();
                } else {}
              }
            }

            PrerealTop = realTop;
            Prerealleft = realleft;
            Prerealwidth = realwidth;
            Prerealheight = realheight;

        }, 500);
    }());
};

function EnableMouse() {
    //event.preventDefault();

    $.ajax({
        url: EnableMouseUrl,
        type: 'GET',
        cache: false,
    }).done(function() {
    }).fail(function() {
    });
};

function DisableMouse() {
    //event.preventDefault();

    $.ajax({
        url: DisableMouseUrl,
        type: 'GET',
        cache: false,
    }).done(function() {
    }).fail(function() {
    });
};

window.onbeforeunload = function(e) {
  Uninitial();

  var milliseconds = 500;
  var start = new Date().getTime();

  while(true) {
    if ((new Date().getTime() - start) > milliseconds)
    break;
  }
};

function Uninitial() {
  DisableMouse();
};

function Initial() {
    canvas = document.getElementById('ppCanvas');
    if(canvas.getContext) {
        context = canvas.getContext('2d');
    }

  if(screen) {
    if(screen.deviceXDPI && screen.logicalXDPI && screen.deviceXDPI!==0 && screen.logicalXDPI!==0) {
      DpiRatio = screen.deviceXDPI/screen.logicalXDPI;
    }
  }
  EnableMouse();

  ShowContrast();
  isPolling = true;
  getInk();
  UpdateCanvasPosition();
};

function clearInk() {
  $.ajax({
      url: clrInkUrl,
      type: 'GET',
      cache: false,
      success: function () {
          var canvas = document.getElementById('ppCanvas');

          context.clearRect(0, 0, canvas.width, canvas.height);
      }
  });
};

function Resign() {
  clearInk();
};

function SignDone() {
  isPolling = false;

  DisableMouse()
  HideButton();

  var RequestParameter = 'nLeft=-1&nTop=-1&nWidth=-1&nHeight=-1';
  $.ajax({
      url: UpdateSignCanvasPositionUrl+RequestParameter,
      type: 'GET',
      cache: false,
  }).done(function(data) {
  });

  $.ajax({
      url: PWC_SignatureCompleted,
      type: 'GET',
      cache: false,
  }).done(function(response) {
  });
};


function HideButton() {
  document.getElementById("SignButtons").style.display = "none";
  document.getElementById("Content_Scroll_Buttons").style.display = "none";
}
