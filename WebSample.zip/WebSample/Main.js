/* global jQuery */
/*eslint-disable*/

'use strict';

// API Url

var apiUrl = 'http://localhost:8089/PPSignSDK/';
//var apiUrl = 'https://localhost:8090/PPSignSDK/';

// initialize device web api
var initUrl = apiUrl + 'InitialDevice?id=9&';
// uninitialize device web api
var uninitUrl = apiUrl + 'UninitialDevice?id=9';

var PWC_Navigate = apiUrl + 'PWC_Navigate?url=';
var PWC_NavigateFinished = apiUrl + 'PWC_NavigateFinished';
var PWC_Shutdown = apiUrl + 'PWC_Shutdown';
var PWC_IsSignatureCompleted = apiUrl + 'PWC_IsSignatureCompleted';
var PWC_SaveWebPageAsPDF = apiUrl + 'PWC_SaveWebPageAsPDF?pdfpath=';
var PWC_SaveWebPageAsPDFFinished = apiUrl + 'PWC_SaveWebPageAsPDFFinished';

var PWC_IsEvaluationCompleted = apiUrl + 'PWC_IsEvaluationCompleted';
var PWC_GetEvaluationResult = apiUrl + 'PWC_GetEvaluationResult';
// get ink web api
var getInkUrl = apiUrl + 'GetInks';
// clear ink api
var clrInkUrl = apiUrl + 'Clear';
// open & close LCD api
var oplcdUrl = apiUrl + 'OpenLCD';
var cllcdUrl = apiUrl + 'CloseLCD';
// get pen width api
var penwidthUrl = apiUrl + 'SetPenWidth?Width=';
// get pen style api
var penstyUrl = apiUrl + 'SetPenStyle?Style=';
// get save drawing api
var savedrawUrl = apiUrl + 'SaveDrawingImage?';
// get size api
var getsizeUrl = apiUrl + 'GetSize';
// get point api
var getpointUrl = apiUrl + 'GetPointer';
// get about api
var aboutUrl = apiUrl + 'About';
// get Version ID api ( for L398 & E560 )
var veridUrl = apiUrl + 'VersionID';
// get pen ID api ( for L398 & E560 )
var penidUrl = apiUrl + 'PenID';
// get pad ID api ( for L398 & E560 )
var padidUrl = apiUrl + 'PadID';
// Display device information in LCD api ( only for L398 )
var diilUrl = apiUrl + 'DisplayDeviceInfoInLCD?show=';
// Get device information api
var devinfoUrl = apiUrl + 'GetDeviceInfo?type=';
// get Encode api
var encodeUrl = apiUrl + 'Encode?type=';
// get Decode api
var decodeUrl = apiUrl + 'Decode?type=';
// get Set clip api
var setclipUrl = apiUrl + 'SetClip';
// get valid api
var validUrl = apiUrl + 'IsValid';
// save device data api
var savedataUrl = apiUrl + 'SaveDeviceData';
// read device data api
var readdataUrl = apiUrl + 'ReadDeviceData';
// save device data api
var cleardataUrl = apiUrl + 'ClearDeviceData';
// Get Decode File Path
var decodepathUrl = apiUrl + 'GetDecodeFilePath';
// GetDeviceConfirmOrCancelKeyStatus
var confirmStatusUrl = apiUrl + 'GetDeviceConfirmOrCancelKeyStatus';
// Save draw video
var saveDrawingVideoUrl = apiUrl + 'SaveDrawingVideo';
// Get video base64 code
var getDrawingVideoBase64DataUrl = apiUrl + 'GetDrawingVideoBase64Data';
// Enable Save Video Data
var enableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=1';
var disableSaveVideoDataUrl = apiUrl + 'EnableSaveVideoData?show=0';

var EnableMouseUrl = apiUrl + 'EnableMouse?enable=1';
var UpdateSignCanvasPositionUrl = apiUrl + 'UpdateWebSignatureCanvasPosition?';

var TestApi = apiUrl + 'Test';

var canvas;
var context;

var isPolling = false;

var filenameCache = '';
var checkVideoIsGeneratge = false;
var isFirstPlay = true;

var LastVideoBase64Resp;

var DpiRatio = 1.0;
var SignWidth = 380;
var SignHeight = 190;



var CurrentPlayMode = -1;

var LastSignImagePath;
var LastSignVideoPath;
var ListSignPDFPath;

String.prototype.replaceAll = function(search, replacement) {
  var target = this;
  return target.replace(new RegExp(search, 'g'), replacement);
};

function isEmpty(str) {
    return (!str || 0 === str.length);
}


function GetHDID() {
  $.ajax({
      url: padidUrl,
      type: 'GET',
      cache: false,
  }).done(function(response) {
    document.getElementById("HDID").innerHTML = response;
  }).fail(function() {
  });
}

function SetPenStyle() {
  var psVal = $('#PenStyleSelect').val();
  console.log(psVal);
  $.ajax({
      url: penstyUrl + psVal,
      type: 'GET',
      cache: false,
  });
}

function clearInk() {

    $.ajax({
        url: clrInkUrl,
        type: 'GET',
        cache: false,
        success: function success() {
        }
    });
}

function SetPenWidth() {
  var pwVal = $('#PenWidthSelect').val();
  console.log(pwVal);
  $.ajax({
      url: penwidthUrl + pwVal,
      type: 'GET',
      cache: false,
  }).done(function () {
      clearInk();
  });
}

function TestHandShake() {
  //console.log('before TestHandShake');
  $.ajax({
      url: TestApi,
      type: 'GET',
      cache: false,
  }).done(function() {
      //console.log('TestHandShake complete');
  }).fail(function() {

  });
}

function Initial() {
  TestHandShake();
  initDevice();
}

var beforeTime;
// initialize device
function initDevice() {

  document.getElementById("displayType").innerHTML = '侦测硬件中';

  var realwidth = (380*window.devicePixelRatio).toFixed(0);
  var realheight = (213*window.devicePixelRatio).toFixed(0);

  beforeTime = Date.now();
  //alert('before initial, time : ' + beforeTime);
    $.ajax({
        url: initUrl+'width='+realwidth+'&height='+realheight,
        type: 'GET',
        cache: false,
    }).done(function(response) {
        console.log(response);
        if(response === true) {
          var NowTime = Date.now();
          //alert('initial completed , time(ms) : ' + (NowTime-beforeTime));
          beforeTime = NowTime;
          document.getElementById("displayType").innerHTML = '侦测硬件中';
            isPolling = true;
            PlayAD();
            //getInk();
            //UpdateCanvasPosition();

        }
        else {
          alert('No device!');
        }
      }).fail(function (jqXHR, textStatus, errorThrown) {
        alert('Connection fail(' + jqXHR.status+')!');
      });
}

var pollingPWC_NavigateFinished = false;

function CheckFinished() {
  ///////////////////////
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(pollingPWC_NavigateFinished)
          {
            $.ajax({
                url: PWC_NavigateFinished,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                pollingPWC_NavigateFinished = false;
                document.getElementById("displayType").innerHTML = '推播网页完成';
                document.getElementById("ShowContrast").disabled = false;
                document.getElementById("ShowAD").disabled = false;
                document.getElementById("btnScore").disabled = false;
                ShowContrast();
              }
            }).always(function() {
                if(pollingPWC_NavigateFinished) {
                    poll();
                } else {}
            });
          }
      }, 500);
  }());
}


var pollingPWC_NavigateADFinished = false;

function CheckADFinished() {
  ///////////////////////
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(pollingPWC_NavigateADFinished)
          {
            $.ajax({
                url: PWC_NavigateFinished,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                pollingPWC_NavigateADFinished = false;
                document.getElementById("displayType").innerHTML = '推播广告网页完成';
                document.getElementById("ShowContrast").disabled = false;
                document.getElementById("ShowAD").disabled = false;
                document.getElementById("btnScore").disabled = false;
              }
            }).always(function() {
                if(pollingPWC_NavigateADFinished) {
                    poll();
                } else {}
            });
          }
      }, 500);
  }());
}

function getEvaluationResult() {
  $.ajax({
      url: PWC_GetEvaluationResult,
      type: 'GET',
      cache: false,
  }).done(function(response) {
    document.getElementById("SCOREID").innerHTML = response+'颗星';
  }).always(function() {
  });
}

var isPollingScoreComplete = false;
function CheckIsIsScoreCompleted() {
  document.getElementById("displayType").innerHTML = '等待评分中';
  isPollingScoreComplete = true;
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(isPollingScoreComplete)
          {
            $.ajax({
                url: PWC_IsEvaluationCompleted,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                isPollingScoreComplete = false;
                document.getElementById("displayType").innerHTML = '评分完成';
                getEvaluationResult();
                PlayAD();
              }
            }).always(function() {
                if(isPollingScoreComplete) {
                    poll();
                } else {}
            });
          }
      }, 1000);
  }());
}

var pollingPWC_NavigateScoreFinished = false;

function CheckScoreFinished() {
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(pollingPWC_NavigateScoreFinished)
          {
            $.ajax({
                url: PWC_NavigateFinished,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                pollingPWC_NavigateScoreFinished = false;
                document.getElementById("displayType").innerHTML = '推播评分网页完成';
                document.getElementById("ShowContrast").disabled = false;
                document.getElementById("ShowAD").disabled = false;
                document.getElementById("btnScore").disabled = false;
                CheckIsIsScoreCompleted();
              }
            }).always(function() {
                if(pollingPWC_NavigateScoreFinished) {
                    poll();
                } else {}
            });
          }
      }, 500);
  }());
}

function ShowScore() {
  if(CurrentPlayMode===3) {
    return;
  }
  CurrentPlayMode = 3;
  document.getElementById("SCOREID").innerHTML = '';

  document.getElementById("ShowAD").disabled = true;
  document.getElementById("ShowContrast").disabled = true;
  document.getElementById("btnScore").disabled = true;

  var loc = window.location.pathname;
  var dir = loc.substring(1, loc.lastIndexOf('/'));
  dir = dir.replaceAll("%20", " ");
  $.ajax({
      url: PWC_Navigate+dir+'/Score.html',
      type: 'GET',
      cache: false,
  }).done(function(response) {
    if(response === 'true') {
      document.getElementById("displayType").innerHTML = '推播评分网页中';
      pollingPWC_NavigateScoreFinished = true;
      CheckScoreFinished();
    }
  }).fail(function() {
  });
}

function PlayAD() {
  if(CurrentPlayMode===1) {
    CurrentPlayMode = 2;
  }
  else {
    CurrentPlayMode = 1;
  }
  document.getElementById("ShowAD").disabled = true;
  document.getElementById("ShowContrast").disabled = true;
  document.getElementById("btnScore").disabled = true;

  isPollingSignComplete = false;

  var loc = window.location.pathname;
  var dir = loc.substring(1, loc.lastIndexOf('/'));
  dir = dir.replaceAll("%20", " ");
  document.getElementById("displayType").innerHTML = '侦测硬件中';

  var NowTime = Date.now();
  //alert('before PWC_Navigate , time(ms) : ' + (NowTime-beforeTime));
  beforeTime = NowTime;

  $.ajax({
      url: PWC_Navigate+dir+'/AD'+CurrentPlayMode+'.html',
      type: 'GET',
      cache: false,
  }).done(function(response) {
    var NowTime = Date.now();
    //alert('PWC_Navigate complete , time(ms) : ' + (NowTime-beforeTime));
    beforeTime = NowTime;
    if(response === 'true') {
      document.getElementById("displayType").innerHTML = '推播广告网页中';
      pollingPWC_NavigateADFinished = true;
      CheckADFinished();
    }
  }).fail(function() {
  });
}

function PushContrast() {
  console.log('PushContrast');
  if(CurrentPlayMode===0) {
    return;
  }

  document.getElementById("ShowAD").disabled = true;
  document.getElementById("ShowContrast").disabled = true;
  document.getElementById("btnScore").disabled = true;
  CurrentPlayMode = 0;

  var loc = window.location.pathname;
  var dir = loc.substring(1, loc.lastIndexOf('/'));
  dir = dir.replaceAll("%20", " ");
  console.log(dir);
  $.ajax({
      url: PWC_Navigate+dir+'/pushed.html',
      type: 'GET',
      cache: false,
  }).done(function(response) {
    if(response === 'true') {
      document.getElementById("displayType").innerHTML = '推播网页中';
      pollingPWC_NavigateFinished = true;
      CheckFinished();
    }
  }).fail(function() {
  });
}

function EnableMouse() {
    //event.preventDefault();

    $.ajax({
        url: EnableMouseUrl,
        type: 'GET',
        cache: false,
    }).done(function() {
    }).fail(function() {
        alert('Enable Mouse Fail')
    });
}

window.onbeforeunload = function(e) {
  isPolling = false;

  Uninitial();

  var milliseconds = 500;
  var start = new Date().getTime();

  while(true) {
    if ((new Date().getTime() - start) > milliseconds) {
      break;
    }
  }
}

function uninitDevice() {
    var done = false;
    $.ajax({
        url: uninitUrl,
        type: 'GET',
        cache: false,
    }).done(function() {
    }).fail(function() {
    });
}

function UninitPWC() {
  $.ajax({
      url: PWC_Shutdown,
      type: 'GET',
      cache: false,
  }).done(function() {
  }).fail(function() {
  });
}

function Uninitial() {
  UninitPWC();

  var milliseconds = 500;
  var start = new Date().getTime();

  while(true) {
    if ((new Date().getTime() - start) > milliseconds) {
      break;
    }
  }

  uninitDevice();
}


function CheckContrast() {
  var psVal = $('#ContractSelect').val();

  if(ListSignPDFPath && psVal === '0') {
    window.open('file:///'+ListSignPDFPath, "_blank");
  }
  else if(psVal === '1') {
    window.open('contract.html', "_blank");
  }
  else {
    alert('无签名笔迹');
  }
}

var isPollingPDFIsComplete = false;
function CheckPDFIsComplete() {
  isPollingPDFIsComplete = true;
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(isPollingPDFIsComplete)
          {
            $.ajax({
                url: PWC_SaveWebPageAsPDFFinished,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                isPollingPDFIsComplete = false;
                clearInk();
                document.getElementById("displayType").innerHTML = 'pdf储存完成';
                document.getElementById("ContractBtn").disabled = false;
                document.getElementById("ContractSelect").disabled = false;
                PlayAD();
              }
            }).always(function() {
                if(isPollingPDFIsComplete) {
                    poll();
                } else {}
            });
          }
      }, 1000);
  }());
}

function savePDF() {
  var now = new Date();
  var loc = window.location.pathname;
  var dir = loc.substring(1, loc.lastIndexOf('/'));
  dir = dir.replaceAll("%20", " ");
  var pdfPath = dir + '/tmp/' +now.getUTCFullYear() + now.getUTCMonth() + now.getUTCDate() +now.getUTCHours() +now.getUTCMinutes()+now.getUTCSeconds() +'.pdf'

  $.ajax({
      url: PWC_SaveWebPageAsPDF+pdfPath,
      type: 'GET',
      cache: false,
  }).done(function (resp) {
    document.getElementById("displayType").innerHTML = '储存pdf中';
    ListSignPDFPath = pdfPath;
    CheckPDFIsComplete();
  });
}

// save drawing images
function saveDrawing() {
  var now = new Date();

  var getsdType = '3';
  var getsdDpi = '1';
  //var localPath = 'DrawImage_' + now.getUTCFullYear() + now.getUTCMonth() + now.getUTCDate() +now.getUTCHours() +now.getUTCMinutes()+now.getUTCSeconds();
  var loc = window.location.pathname;
  var dir = loc.substring(1, loc.lastIndexOf('/'));
  dir = dir.replaceAll("%20", " ");
  var localPath = dir + "/tmp/signImg";

  localPath = localPath.replaceAll('/','\\');

  var sdT = '.PNG';
  var sdD = '300';

  $.ajax({
      url: savedrawUrl + 'type=' + getsdType + '&dpi=' + getsdDpi + '&path=' + localPath + sdT,
      type: 'GET',
      cache: false,
  }).done(function (resp) {
      if (Boolean(parseInt(resp))) {
          alert('Save file ' + localPath + ' failed' + ', result=' + resp);
      } else {
        savePDF();
          if (navigator.userAgent.indexOf("WOW64") != -1 || navigator.userAgent.indexOf("Win64") != -1) {
              //alert('File：' + resp + ' saved\nDpi：' + sdD);
          } else {
              //alert('File：' + resp + ' saved\nDpi：' + sdD);
          }
      }
  });
};

function SaveSign() {
  saveDrawing();
}

var isPollingSignComplete = false;
function CheckIsIsSignatureCompleted() {
  document.getElementById("displayType").innerHTML = '等待签名中';
  isPollingSignComplete = true;
  (function poll() {
      var timeId = setTimeout(function() {
          clearTimeout(timeId);
          if(isPollingSignComplete)
          {
            $.ajax({
                url: PWC_IsSignatureCompleted,
                type: 'GET',
                cache: false,
            }).done(function(response) {
              if(response === true) {
                isPollingSignComplete = false;
                document.getElementById("displayType").innerHTML = '签名完成';
                SaveSign();
              }
            }).always(function() {
                if(isPollingSignComplete) {
                    poll();
                } else {}
            });
          }
      }, 1000);
  }());
}

function ShowContrast() {
  //clearInk();
  CheckIsIsSignatureCompleted();
}
